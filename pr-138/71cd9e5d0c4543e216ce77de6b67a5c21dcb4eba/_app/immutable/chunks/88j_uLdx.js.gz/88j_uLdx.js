const s=globalThis.__sveltekit_1yh136f?.base??"/AlgoWeb",e=globalThis.__sveltekit_1yh136f?.assets??s??"";export{e as a,s as b};
