const s=globalThis.__sveltekit_b9womt?.base??"/AlgoWeb",t=globalThis.__sveltekit_b9womt?.assets??s??"";export{t as a,s as b};
