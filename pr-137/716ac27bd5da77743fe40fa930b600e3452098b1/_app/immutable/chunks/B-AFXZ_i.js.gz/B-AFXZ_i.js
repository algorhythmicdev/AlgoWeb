const s=globalThis.__sveltekit_wvvgtb?.base??"/AlgoWeb",t=globalThis.__sveltekit_wvvgtb?.assets??s??"";export{t as a,s as b};
