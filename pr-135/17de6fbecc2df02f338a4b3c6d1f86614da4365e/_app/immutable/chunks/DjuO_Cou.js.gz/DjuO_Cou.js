const s=globalThis.__sveltekit_ba96gk?.base??"/AlgoWeb",a=globalThis.__sveltekit_ba96gk?.assets??s??"";export{a,s as b};
